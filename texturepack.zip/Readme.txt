Credits:
ullert

Some resources borowed from our very popular Fallout Paradise resource pack:
http://www.planetminecraft.com/texture_pack/fallout-paradise-3410650/

Software:
Free texture editing tool.
Gimp 2.8 - https://www.gimp.org/
---
Custom models created with MrCrayfish's awesome model creator!
Link: https://mrcrayfish.com/tools?id=mc